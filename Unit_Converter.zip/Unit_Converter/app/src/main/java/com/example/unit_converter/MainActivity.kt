package com.example.unit_converter

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var inputUnitSpinner: Spinner
    private lateinit var outputUnitSpinner: Spinner
    private lateinit var inputEditText: EditText
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputUnitSpinner = findViewById(R.id.spinnerInputUnit)
        outputUnitSpinner = findViewById(R.id.spinnerOutputUnit)
        inputEditText = findViewById(R.id.editTextInput)
        resultTextView = findViewById(R.id.textViewResult)
        val convertButton: Button = findViewById(R.id.buttonConvert)

        // Populate spinners with unit options
        val unitOptions = arrayOf("Gram", "Kilogram", "Milligram")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, unitOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)


        inputUnitSpinner.adapter = adapter
        outputUnitSpinner.adapter = adapter

        inputUnitSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        outputUnitSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        convertButton.setOnClickListener {
            convertWeight()
        }
    }

    private fun convertWeight() {
        val inputValue = inputEditText.text.toString().toDoubleOrNull()

        if (inputValue != null) {
            val inputUnit = inputUnitSpinner.selectedItem.toString()
            val outputUnit = outputUnitSpinner.selectedItem.toString()

            val result = when (Pair(inputUnit, outputUnit)) {
                Pair("Kilogram", "Gram") -> inputValue * 1000
                Pair("Kilogram", "Milligram") -> inputValue * 1e+6
                Pair("Gram", "Kilogram") -> inputValue / 1000
                Pair("Gram", "Milligram") -> inputValue * 1000
                Pair("Milligram", "Kilogram") -> inputValue / 1e+6
                Pair("Milligram", "Gram") -> inputValue / 1000
                else -> inputValue
            }

            resultTextView.text = "Weight: $result $outputUnit"
        } else {
            resultTextView.text = "Result: Enter a valid value"
        }
    }

}